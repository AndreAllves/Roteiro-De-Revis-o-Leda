package forma;

public abstract class Forma {
    
    Forma() {
    }

    public abstract double area();

    
}
